/*
 * GPIO_config.h
 *
 *  Created on: May 11, 2023
 *      Author: ss210
 */

#ifndef MCAL_GPIO_GPIO_CONFIG_H_
#define MCAL_GPIO_GPIO_CONFIG_H_



#endif /* MCAL_GPIO_GPIO_CONFIG_H_ */
