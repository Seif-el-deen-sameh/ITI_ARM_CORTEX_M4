/*
 * EXTI_config.h
 *
 *  Created on: May 28, 2023
 *      Author: ss210
 */

#ifndef MCAL_EXTI_EXTI_CONFIG_H_
#define MCAL_EXTI_EXTI_CONFIG_H_



#endif /* MCAL_EXTI_EXTI_CONFIG_H_ */
