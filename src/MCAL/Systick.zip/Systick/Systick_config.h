/*
 * Systick_config.h
 *
 *  Created on: May 26, 2023
 *      Author: ss210
 */

#ifndef MCAL_SYSTICK_SYSTICK_CONFIG_H_
#define MCAL_SYSTICK_SYSTICK_CONFIG_H_



#endif /* MCAL_SYSTICK_SYSTICK_CONFIG_H_ */
